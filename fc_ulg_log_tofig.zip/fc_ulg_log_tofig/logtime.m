function   [take_offtime,landtime] = logtime(A)
    %% 打开文件并检查是否打开文件
fileID = fopen(A, 'r');
if fileID == -1
    error('无法打开文件');
end
%% 用ci来保存第几次飞行
ci = 0;
%% 保存关键字识别，建立元胞数组存储时间
take_offs = ' [I|ap]: [ADSP]Entering Task: TakeOff';
lands = ' [I|ap]: [ADSP][TaskManager] Reset to IDLE in disarm';
take_offtime = {};
landtime ={};
%% 开始对文件进行逐行处理
while  ~feof(fileID)  %保证读完整个文件
    line = fgetl(fileID);  % 读取一行,用fget1读到换行然后丢掉换行符
    if(contains(line, take_offs))
        ci = ci+1; %%新的飞行
        postion = strfind(line,take_offs);
        time = line(postion-20:postion-2);
        timestr = line(2:postion-22);%用于转化字符串为时间
        %fprintf("%s",timestr);
        timedur = duration(0,0,str2double(timestr)/1000);
        fprintf('第%d次: 起飞时间: %s %.2fs', ci,time,seconds(timedur));
        %disp(timedur);
        take_offtime{end+1} = timedur;
    end
    if(contains(line, lands) &&ci)%%表示飞机起飞才会降落
        postion = strfind(line,lands);
%         time = line(2:postion-2);
%         fprintf('您好开始第%d次降落！\n第%d次降落的时间为 "%s"\n', ci, ci,time);
%         timestr = line(postion-9:postion-2);%用于转化字符串为时间
%         timedur = duration(timestr, 'InputFormat','hh:mm:ss');
%         %disp(timedur);
%         landtime{end+1} = timedur;
        time = line(postion-20:postion-2);
        timestr = line(2:postion-22);%用于转化字符串为时间
        %fprintf("%s",timestr);
        timedur = duration(0,0,str2double(timestr)/1000);
        fprintf('  持续时间: %.2fs\n', seconds(timedur)-seconds(take_offtime{end}));
        landtime{end+1} = timedur;
    end
end
%% 结束工作
% 关闭文件
fclose(fileID);
end