clc ; clear all;close all;
%% 选择log文件并得到起飞降落时间
[takeoff_time,land_time] = logtime('ffc.log');
%% 选择ulog
ulog_file = "ffc_data_log.ulg";
ulog = ulogreader(ulog_file); 
%% 如果炸机 以结束时间为降落时间
if(length(land_time) ~= length(takeoff_time))
    land_time{end+1} = ulog.EndTime;
end
%% 画图
    for i = 1:length(takeoff_time)
        fc_ulg_plot(ulog,takeoff_time{i},land_time{i},i);
        fprintf('第%d次已经结束\n', i);
    end
