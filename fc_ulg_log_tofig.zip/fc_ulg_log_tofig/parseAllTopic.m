function all_ulog_data = parseAllTopic(ulog_obj, T1, T2)

ulog = readTopicMsgs(ulog_obj, 'Time', [T1 T2]);%才真正拿到数据
TopicNames = ulog.TopicNames;
TopicMessages = ulog.TopicMessages;


for idx = 1:length(TopicNames)
    all_ulog_data.(TopicNames{idx}) = timetable2table(TopicMessages{idx});%本来是时间+数据的cell的timetable模式
    %转换为table模式合并成一个表了
    % 把时间的格式顺便也转换了 将时间截的时间转化为只有秒
    all_ulog_data.(TopicNames{idx}).timestamp = seconds(all_ulog_data.(TopicNames{idx}).timestamp);
end

end