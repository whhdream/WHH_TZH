% 示例字符串
str = 'Hello, world! Welcome to the world of MATLAB.';

% 子字符串
subStr = 'world';

% 使用 strfind 找到子字符串第一次出现的位置
positions = strfind(str, subStr);

% 检查是否找到子字符串
if ~isempty(positions)
    firstPosition = positions(1);
    fprintf('子字符串 "%s" 第一次出现在位置 %d。\n', subStr, firstPosition);
else
    fprintf('字符串不包含子字符串 "%s"。\n', subStr);
end