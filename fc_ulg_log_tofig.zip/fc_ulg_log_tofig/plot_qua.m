function plot_qua (q, ok)
    R = rotmat(q, 'frame');
    %得到旋转后的新向量
    if ok %表示期望值的绘制
        x_new = R * [5; 0; 0];
        y_new = R * [0; -5; 0];
        z_new = R * [0; 0; -5];
    % 绘制 X 轴
        quiver3(0, 0, 0, x_new(1), x_new(2), x_new(3), 'Color', [1, 0, 0], 'LineWidth', 1.5,'LineStyle', '--');
        text(x_new(1), x_new(2), x_new(3), 'X_d', 'Color', [1, 0, 0], 'FontSize', 6, 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');
        hold on
    % 绘制 Y 轴
        quiver3(0, 0, 0, y_new(1), y_new(2), y_new(3), 'Color', [0, 1, 0], 'LineWidth', 1.5,'LineStyle', '--');
        text(y_new(1), y_new(2), y_new(3), 'Y_d', 'Color', [0, 1, 0], 'FontSize', 6, 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');
    
    % 绘制 Z 轴
        quiver3(0, 0, 0, z_new(1), z_new(2), z_new(3), 'Color', [0, 0, 1], 'LineWidth', 1.5,'LineStyle', '--');
        text(z_new(1), z_new(2), z_new(3), 'Z_d', 'Color', [0, 0, 1], 'FontSize', 6, 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');
        set(gca,'XLim',[-1 1]);%设置x轴显示范围
        set(gca,'YLim',[-1 1]);%设置y轴显示范围
        set(gca,'ZLim',[-1 1]);%设置z轴显示范围
        ax = gca;
        ax.DataAspectRatio = [1 1 1];
    else
        x_new = R * [1.5; 0; 0];
        y_new = R * [0; -1.5; 0];
        z_new = R * [0; 0; -1.5];
    % 绘制 X 轴
        quiver3(0, 0, 0, x_new(1), x_new(2), x_new(3), 'Color', [0, 0, 0], 'LineWidth', 1.5);
        text(x_new(1), x_new(2), x_new(3), 'X', 'Color', [0, 0, 0], 'FontSize', 6, 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');
        hold on
    % 绘制 Y 轴
        quiver3(0, 0, 0, y_new(1), y_new(2), y_new(3), 'Color', [1, 0.5, 0], 'LineWidth', 1.5);
        text(y_new(1), y_new(2), y_new(3), 'Y', 'Color', [1, 0.5, 0], 'FontSize', 6, 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');
    
    % 绘制 Z 轴
        quiver3(0, 0, 0, z_new(1), z_new(2), z_new(3), 'Color', [0.5, 0, 0.5], 'LineWidth', 1.5);
        text(z_new(1), z_new(2), z_new(3), 'Z', 'Color', [0.5, 0, 0.5], 'FontSize', 6, 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');
        set(gca,'XLim',[-2 2]);%设置x轴显示范围
        set(gca,'YLim',[-2 2]);%设置y轴显示范围
        set(gca,'ZLim',[-2 2]);%设置z轴显示范围
        ax = gca;
        ax.DataAspectRatio = [1 1 1];
    end
end